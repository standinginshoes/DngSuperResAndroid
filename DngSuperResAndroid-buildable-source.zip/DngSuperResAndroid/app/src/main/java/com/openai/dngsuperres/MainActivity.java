package com.openai.dngsuperres;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_DNGS = 1001;
    private static final int SAVE_RESULT = 1002;
    private static final int PREVIEW_MAX = 384;
    private static final int SEARCH_RADIUS = 14;

    private final ArrayList<Uri> frames = new ArrayList<>();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private Bitmap resultBitmap;

    private TextView status;
    private TextView details;
    private ProgressBar progress;
    private Button processButton;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
    }

    private View buildUi() {
        int pad = dp(20);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("DNG Super Resolution");
        title.setTextSize(28);
        title.setTextColor(Color.rgb(20,20,20));
        title.setPadding(0, dp(8), 0, dp(4));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Offline 2× multi-frame stacker • MVP v0.1");
        subtitle.setTextSize(15);
        subtitle.setTextColor(Color.DKGRAY);
        subtitle.setPadding(0, 0, 0, dp(18));
        root.addView(subtitle);

        Button select = new Button(this);
        select.setText("Select DNG burst");
        select.setOnClickListener(v -> pickDngs());
        root.addView(select, matchWrap());

        processButton = new Button(this);
        processButton.setText("Build 2× Super Resolution");
        processButton.setEnabled(false);
        processButton.setOnClickListener(v -> startProcessing());
        root.addView(processButton, matchWrap());

        saveButton = new Button(this);
        saveButton.setText("Save PNG");
        saveButton.setEnabled(false);
        saveButton.setOnClickListener(v -> chooseSaveLocation());
        root.addView(saveButton, matchWrap());

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        LinearLayout.LayoutParams pp = matchWrap();
        pp.topMargin = dp(18);
        root.addView(progress, pp);

        status = new TextView(this);
        status.setText("Select 2 or more DNG files.");
        status.setTextSize(17);
        status.setPadding(0, dp(12), 0, dp(8));
        root.addView(status);

        details = new TextView(this);
        details.setText("The current build decodes DNGs through Android's image pipeline, estimates translation from grayscale previews, and averages the aligned full-resolution frames into a 2× output. True Bayer/CFA fusion is the next processing-engine upgrade.");
        details.setTextSize(14);
        details.setTextColor(Color.DKGRAY);
        details.setPadding(0, dp(6), 0, dp(20));
        root.addView(details);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        return scroll;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void pickDngs() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, PICK_DNGS);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;

        if (requestCode == PICK_DNGS) {
            frames.clear();
            if (data.getClipData() != null) {
                for (int n = 0; n < data.getClipData().getItemCount(); n++) {
                    addFrame(data.getClipData().getItemAt(n).getUri());
                }
            } else if (data.getData() != null) {
                addFrame(data.getData());
            }
            Collections.sort(frames, Comparator.comparing(this::displayName));
            status.setText(frames.size() + " frame(s) selected");
            processButton.setEnabled(frames.size() >= 2);
            saveButton.setEnabled(false);
            resultBitmap = null;
        } else if (requestCode == SAVE_RESULT && data.getData() != null) {
            saveResult(data.getData());
        }
    }

    private void addFrame(Uri uri) {
        if (uri == null || frames.contains(uri)) return;
        frames.add(uri);
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
    }

    private void startProcessing() {
        final ArrayList<Uri> snapshot = new ArrayList<>(frames);
        processButton.setEnabled(false);
        saveButton.setEnabled(false);
        progress.setProgress(0);
        status.setText("Analyzing reference frame…");

        executor.execute(() -> {
            try {
                List<FrameInfo> info = new ArrayList<>();
                for (int i = 0; i < snapshot.size(); i++) {
                    Bitmap preview = decodePreview(snapshot.get(i));
                    if (preview == null) throw new IllegalStateException("Could not decode " + displayName(snapshot.get(i)));
                    double sharpness = sharpness(preview);
                    info.add(new FrameInfo(snapshot.get(i), preview, sharpness));
                    updateProgress((int)(20.0 * (i + 1) / snapshot.size()), "Analyzing frame " + (i + 1) + "/" + snapshot.size());
                }

                FrameInfo ref = Collections.max(info, Comparator.comparingDouble(f -> f.sharpness));
                runOnUiThread(() -> status.setText("Reference: " + displayName(ref.uri) + " • aligning…"));

                for (int i = 0; i < info.size(); i++) {
                    FrameInfo f = info.get(i);
                    if (f == ref) {
                        f.dxPreview = 0;
                        f.dyPreview = 0;
                    } else {
                        double[] shift = estimateShift(ref.preview, f.preview);
                        f.dxPreview = shift[0];
                        f.dyPreview = shift[1];
                    }
                    updateProgress(20 + (int)(30.0 * (i + 1) / info.size()), "Aligned " + (i + 1) + "/" + info.size());
                }

                Bitmap refFull = decodeFull(ref.uri);
                if (refFull == null) throw new IllegalStateException("Reference DNG could not be decoded at full resolution.");
                int w = refFull.getWidth();
                int h = refFull.getHeight();
                long outPixels = (long)w * 2L * (long)h * 2L;
                if (outPixels > 70_000_000L) {
                    throw new IllegalStateException("2× output is " + (w*2) + "×" + (h*2) + ". This MVP caps output at 70 MP to reduce out-of-memory crashes.");
                }

                Bitmap out = Bitmap.createBitmap(w * 2, h * 2, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(out);
                Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);

                ArrayList<FrameInfo> ordered = new ArrayList<>();
                ordered.add(ref);
                for (FrameInfo f : info) if (f != ref) ordered.add(f);

                for (int i = 0; i < ordered.size(); i++) {
                    FrameInfo f = ordered.get(i);
                    Bitmap full = (f == ref) ? refFull : decodeFull(f.uri);
                    if (full == null) continue;
                    if (full.getWidth() != w || full.getHeight() != h) {
                        full.recycle();
                        continue;
                    }

                    float previewScaleX = (float)w / (float)f.preview.getWidth();
                    float previewScaleY = (float)h / (float)f.preview.getHeight();
                    float dxFull = (float)f.dxPreview * previewScaleX;
                    float dyFull = (float)f.dyPreview * previewScaleY;

                    paint.setAlpha(i == 0 ? 255 : Math.max(1, Math.round(255f / (i + 1f))));
                    canvas.save();
                    canvas.scale(2f, 2f);
                    canvas.translate(-dxFull, -dyFull);
                    canvas.drawBitmap(full, 0f, 0f, paint);
                    canvas.restore();

                    if (full != refFull) full.recycle();
                    updateProgress(50 + (int)(48.0 * (i + 1) / ordered.size()), "Stacking " + (i + 1) + "/" + ordered.size());
                }

                for (FrameInfo f : info) f.preview.recycle();
                refFull.recycle();
                resultBitmap = out;
                runOnUiThread(() -> {
                    progress.setProgress(100);
                    status.setText("Done • " + out.getWidth() + "×" + out.getHeight() + " • " + snapshot.size() + " frames");
                    details.setText("Reference chosen by preview sharpness. Translation alignment used a coarse-to-fine absolute-difference search. Full frames were projected to a 2× canvas and incrementally averaged. Save the current result as lossless PNG.");
                    processButton.setEnabled(true);
                    saveButton.setEnabled(true);
                });
            } catch (Throwable t) {
                runOnUiThread(() -> {
                    status.setText("Processing failed: " + t.getMessage());
                    processButton.setEnabled(true);
                    saveButton.setEnabled(false);
                    Toast.makeText(this, t.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private Bitmap decodePreview(Uri uri) throws Exception {
        ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
        return ImageDecoder.decodeBitmap(source, (decoder, info, src) -> {
            int w = info.getSize().getWidth();
            int h = info.getSize().getHeight();
            float scale = Math.min(1f, PREVIEW_MAX / (float)Math.max(w, h));
            decoder.setTargetSize(Math.max(32, Math.round(w * scale)), Math.max(32, Math.round(h * scale)));
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            decoder.setMemorySizePolicy(ImageDecoder.MEMORY_POLICY_LOW_RAM);
        });
    }

    private Bitmap decodeFull(Uri uri) throws Exception {
        ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
        return ImageDecoder.decodeBitmap(source, (decoder, info, src) -> {
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            decoder.setMemorySizePolicy(ImageDecoder.MEMORY_POLICY_LOW_RAM);
        });
    }

    private double sharpness(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight();
        int step = 2;
        double sum = 0;
        long count = 0;
        for (int y = 2; y < h - 2; y += step) {
            for (int x = 2; x < w - 2; x += step) {
                int c = luma(b.getPixel(x,y));
                int lap = 4*c - luma(b.getPixel(x-1,y)) - luma(b.getPixel(x+1,y)) - luma(b.getPixel(x,y-1)) - luma(b.getPixel(x,y+1));
                sum += (double)lap * lap;
                count++;
            }
        }
        return count == 0 ? 0 : sum / count;
    }

    private double[] estimateShift(Bitmap ref, Bitmap img) {
        Bitmap candidate = img;
        if (img.getWidth() != ref.getWidth() || img.getHeight() != ref.getHeight()) {
            candidate = Bitmap.createScaledBitmap(img, ref.getWidth(), ref.getHeight(), true);
        }
        int bestX = 0, bestY = 0;
        double best = Double.POSITIVE_INFINITY;
        for (int dy = -SEARCH_RADIUS; dy <= SEARCH_RADIUS; dy += 2) {
            for (int dx = -SEARCH_RADIUS; dx <= SEARCH_RADIUS; dx += 2) {
                double s = shiftCost(ref, candidate, dx, dy, 4);
                if (s < best) { best = s; bestX = dx; bestY = dy; }
            }
        }
        int coarseX = bestX, coarseY = bestY;
        best = Double.POSITIVE_INFINITY;
        for (int dy = coarseY - 2; dy <= coarseY + 2; dy++) {
            for (int dx = coarseX - 2; dx <= coarseX + 2; dx++) {
                double s = shiftCost(ref, candidate, dx, dy, 2);
                if (s < best) { best = s; bestX = dx; bestY = dy; }
            }
        }
        double cxm = shiftCost(ref, candidate, bestX - 1, bestY, 2);
        double cx0 = shiftCost(ref, candidate, bestX, bestY, 2);
        double cxp = shiftCost(ref, candidate, bestX + 1, bestY, 2);
        double cym = shiftCost(ref, candidate, bestX, bestY - 1, 2);
        double cy0 = cx0;
        double cyp = shiftCost(ref, candidate, bestX, bestY + 1, 2);
        double subX = parabolicOffset(cxm, cx0, cxp);
        double subY = parabolicOffset(cym, cy0, cyp);
        if (candidate != img) candidate.recycle();
        return new double[]{bestX + subX, bestY + subY};
    }

    private double parabolicOffset(double left, double center, double right) {
        double denom = left - 2.0 * center + right;
        if (Math.abs(denom) < 1e-9) return 0;
        double v = 0.5 * (left - right) / denom;
        return Math.max(-0.75, Math.min(0.75, v));
    }

    private double shiftCost(Bitmap a, Bitmap b, int dx, int dy, int step) {
        int w = a.getWidth(), h = a.getHeight();
        int margin = SEARCH_RADIUS + 4;
        long total = 0;
        long count = 0;
        for (int y = margin; y < h - margin; y += step) {
            int by = y + dy;
            if (by < 0 || by >= h) continue;
            for (int x = margin; x < w - margin; x += step) {
                int bx = x + dx;
                if (bx < 0 || bx >= w) continue;
                total += Math.abs(luma(a.getPixel(x,y)) - luma(b.getPixel(bx,by)));
                count++;
            }
        }
        return count == 0 ? Double.POSITIVE_INFINITY : (double)total / count;
    }

    private int luma(int c) {
        return (77 * Color.red(c) + 150 * Color.green(c) + 29 * Color.blue(c)) >> 8;
    }

    private void chooseSaveLocation() {
        if (resultBitmap == null) return;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/png");
        i.putExtra(Intent.EXTRA_TITLE, "SuperRes_2x.png");
        startActivityForResult(i, SAVE_RESULT);
    }

    private void saveResult(Uri uri) {
        if (resultBitmap == null) return;
        executor.execute(() -> {
            try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                if (out == null || !resultBitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                    throw new IllegalStateException("PNG encoder failed.");
                }
                runOnUiThread(() -> Toast.makeText(this, "Saved SuperRes_2x.png", Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private String displayName(Uri uri) {
        try (android.database.Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) { }
        return uri.getLastPathSegment() == null ? "frame" : uri.getLastPathSegment();
    }

    private void updateProgress(int value, String text) {
        runOnUiThread(() -> { progress.setProgress(value); status.setText(text); });
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private static final class FrameInfo {
        final Uri uri;
        final Bitmap preview;
        final double sharpness;
        double dxPreview;
        double dyPreview;
        FrameInfo(Uri uri, Bitmap preview, double sharpness) {
            this.uri = uri; this.preview = preview; this.sharpness = sharpness;
        }
    }
}
